# coding=utf-8
import datetime
import sys
import random
import numpy as np
from time import clock

l = 3
blank = [0]*l
sol = {}
sol.setdefault('_'.join([str(1),str(2)]),[0,blank])
print [[0]]*5
