# coding=utf-8
import datetime
import arma
import arma_math
import diff
import math

def predict_ar(day1,day2,data):
	data = arma_math.fil(data)
	data = [a ** (1./2) for a in data]
	firsr_order = 1
	second_order = 7
	temp1 = data[0:firsr_order]
	data = diff.diff(firsr_order,data)
	data = diff.diff(second_order,data[firsr_order:])
	meandata = arma_math.mean_value(data)
	data = arma.decent(meandata,data)
	var = arma_math.var(data)
	try:
		data = [a / var for a in data]
	except ZeroDivisionError:
		var = 1
	phi = arma.AR(data[second_order:])
	d1 = datetime.date(int(day1[:4]),int(day1[5:7]),int(day1[8:10]))
	d2 = datetime.date(int(day2[:4]),int(day2[5:7]),int(day2[8:10]))

	data = ar_predict(data,phi,(d2-d1).days)
	data = [a * var for a in data]
	data = arma.cent(meandata,data)
	data = diff.rediff(second_order,data)
	data = diff.rediff(firsr_order,temp1+data)
	for i in range(len(data)):
		if data[i] < 0:
			data[i] = 0
	data = [a ** 2 for a in data]
	result = round(sum(data[-(d2-d1).days:]))
	if result > 40:
		result = 10
	return result

def ar_predict(data,phi,days):
	for i in range(0,days-1):
		j = -1
		tem_sum = 0
		for value in phi:
			tem_sum += value[0] * data[j]
			j -= 1
		data.append(tem_sum)
	return data
