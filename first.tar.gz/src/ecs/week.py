# coding=utf-8
from datetime import *

print date(2018,3,14).weekday()
